/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
//#include <device.h>
#include <stdio.h>
#include <mem1.h>

void TFT_INIT();

int main()
{
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
     SPIS_1_Start();
    PWM_1_Start();
    TFT_INIT();
    char buffer[50];
    TFTSHIELD_1_PrintString("waiting for SPI\n");
    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        uint8 addr; //addr of component
        uint8 cmd; //cmd for address
        uint32 dat; //dat for cmd if applicable
        /*
            0-7: address
            8-11: cmd
            12-31: value
        */
        uint32 output = 0;
        
        /*while(SPIS_1_ReadRxStatus() == SPIS_1_STS_RX_FIFO_NOT_EMPTY)
        {
            int spi_dat = SPIS_1_ReadRxData();
            sprintf(buffer,"spi: %i\n",spi_dat);
            TFTSHIELD_1_PrintString(buffer);
        }*/
        
        int count = 0;
        while(SPIS_1_ReadRxStatus() == SPIS_1_STS_RX_FIFO_NOT_EMPTY)
        {
            //first byte is address
            if(count == 0)
            {
                addr = SPIS_1_ReadRxData();
                sprintf(buffer,"addr: %i\n",addr);
                //TFTSHIELD_1_PrintString(buffer);
                
            }
            else if(count == 1) //second byte is command
            {
                cmd = SPIS_1_ReadRxData();
                sprintf(buffer,"cmd: %i\n",cmd);
                //TFTSHIELD_1_PrintString(buffer);
                //dat << 8;
                //sprintf(buffer,"dat << 8: %i\n",dat);
                //TFTSHIELD_1_PrintString(buffer);
            }
            else //third and on is data
            {
                dat = SPIS_1_ReadRxData();
                sprintf(buffer,"dat: %i\n",dat);
                //TFTSHIELD_1_PrintString(buffer);
            }
            count++;
        }
        if(count != 0)
        {
            output = readData(addr,cmd,dat);
        }
        //count = 0;
        if(output != 0)
        {
            sprintf(buffer,"output: %i\n",output);
            TFTSHIELD_1_PrintString(buffer);
            uint8 out1 = output >> 8;
            uint8 out2 = output;
            sprintf(buffer,"out1: %i\n",out1);
            //TFTSHIELD_1_PrintString(buffer);
            sprintf(buffer,"out2: %i\n",out2);
            //TFTSHIELD_1_PrintString(buffer);
            SPIS_1_WriteTxData(out1);
            SPIS_1_WriteTxData(out2);
            
            
        }
        
    }
}

void TFT_INIT()
{
    CyDelay(1000);
    Clock_1_SetDividerValue(24);
    CyDelay(10);
    TFTSHIELD_1_StartTouch(); 
    Clock_1_SetDividerValue(1);
    CyDelay(10);
    TFTSHIELD_1_Start();
    TFTSHIELD_1_FillScreen(BLACK);
    TFTSHIELD_1_SetCursor(0,0);//start at 0,0 for text
    TFTSHIELD_1_SetTextColor(WHITE);  
    TFTSHIELD_1_SetTextSize(2);
    TFTSHIELD_1_SetRotation(3);
    CyDelay(10);
}

/* [] END OF FILE */
