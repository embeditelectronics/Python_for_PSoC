#!/usr/bin/env python

from distutils.core import setup
#from setuptools import setup

setup(name='RPiSoC',
      version='1.2.6',
      description='RPiSoC Python API',
      author='Brian Bradley',
      author_email='brian.bradley.p@gmail.com',
      packages=['rpisoc'],
     )